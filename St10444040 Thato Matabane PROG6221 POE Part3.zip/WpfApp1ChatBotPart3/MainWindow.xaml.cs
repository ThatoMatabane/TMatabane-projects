﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Windows;
using System.Windows.Controls;

namespace CybersecurityChatbotWPF
{
    public partial class MainWindow : Window
    {
        private SpeechSynthesizer synth = new();
        private List<string> conversationMemory = new();
        private List<TaskItem> tasks = new();
        private List<string> activityLog = new();
        private string favoriteTopic = null, userName = null;
        private bool quizInProgress = false;
        private int quizIndex = 0, quizScore = 0;

        private readonly List<QuizQuestion> quizQuestions = new()
    {
        new("What should you do if you receive an email asking for your password?",
            new[] {"Reply with your password","Delete the email","Report the email as phishing","Ignore it"},
            2, "Correct! Reporting phishing emails helps prevent scams."),
        new("True or False: Using the same password for multiple sites is safe.",
            new[] {"True","False"}, 1, "Correct! Using the same password is risky if one site is breached."),
        new("What is 2FA?",
            new[] {"Two-Factor Authentication","Two-Faced Application","Fast Access","Password Recovery"},
            0, "Correct! 2FA adds a second step to verify your identity."),
        new("Which of these is the safest password?",
            new[] {"123456","password123","Mypassword!","G8$h9!z@L2"}, 3,
            "Strong passwords include symbols, numbers, and are hard to guess."),
        new("True or False: HTTPS is more secure than HTTP.",
            new[] {"True","False"}, 0, "Correct! HTTPS encrypts data, making it more secure."),
        new("Which is a sign of a phishing email?",
            new[] {"Unknown sender","Spelling mistakes","Urgent tone","All of the above"},
            3, "Correct! Phishing emails often combine multiple suspicious signs."),
        new("When should you update your antivirus software?",
            new[] {"Every 5 years","Only when you have a virus","Regularly","Never"},
            2, "Correct! Regular updates help catch the latest threats."),
        new("True or False: Public Wi-Fi is always safe.",
            new[] {"True","False"}, 1, "Correct! Public Wi-Fi can be risky—use a VPN."),
        new("What is social engineering?",
            new[] {"Computer hacking","Tricking people into giving information","A type of malware","A firewall"},
            1, "Correct! Social engineering manipulates people to breach security."),
        new("Which of these should you NOT do?",
            new[] {"Use 2FA","Open unknown email attachments","Update software","Use strong passwords"},
            1, "Correct! Opening unknown attachments can expose you to malware.")
    };

        private readonly List<string> topicIndicators = new() { "favorite", "love", "like", "enjoy", "interested in", "passionate about", "prefer" };
        private readonly string[] worryWords = { "worried", "afraid", "scared", "concerned", "nervous", "anxious", "fear", "unsure", "uncertain" };
        private readonly string[] angerWords = { "angry", "frustrated", "mad", "upset", "annoyed", "irritated" };
        private readonly string[] sadnessWords = { "sad", "depressed", "unhappy", "disheartened", "hopeless" };
        private readonly Dictionary<string, string> responses = new()
    {
        {"password","Use strong passwords with a mix of letters, numbers, and symbols. Avoid using the same password for multiple accounts."},
        {"phishing","Be cautious of emails or messages asking for personal information. Always verify the sender before clicking links."},
        {"2fa","Enable two-factor authentication (2FA) for an extra layer of security on your accounts."},
        {"malware","Avoid downloading attachments or software from untrusted sources to protect yourself from malware."},
        {"social media","Be mindful of the information you share online. Adjust privacy settings to limit exposure."},
        {"vpn","Using a VPN can help encrypt your internet connection and protect your online privacy."},
        {"firewall","A firewall helps to block unauthorized access to your network. Keep it enabled and updated."},
        {"ransomware","Never open suspicious email attachments or links. Keep backups of important data to mitigate ransomware threats."},
        {"antivirus","Regularly update your antivirus software to detect and remove threats before they cause harm."},
        {"public wifi","Avoid using public Wi‑Fi for sensitive transactions. Use a VPN for better security."},
        {"data breach","Monitor your accounts for suspicious activity and change passwords immediately if a data breach occurs."},
        {"identity theft","Be cautious about sharing personal information online to prevent identity theft."},
        {"updates","Keep your software, operating system, and apps updated to patch security vulnerabilities."},
        {"how can i protect my data","Use strong encryption methods for sensitive data and always back up important files to prevent data loss."},
        {"what is a secure website","A secure website should have HTTPS in its URL. Check for a padlock icon in the address bar to ensure it's secure."},
        {"how do i know if my email has been hacked","Look for unusual activity like unexpected password change notifications or unfamiliar emails sent from your account. Change your password immediately if you suspect a hack."},
        {"should i use public wi‑fi","Public Wi‑Fi is generally not secure. Avoid logging into sensitive accounts on public networks unless you use a VPN."},
        {"what is two‑factor authentication","Two‑factor authentication (2FA) is an extra layer of security where you provide two forms of identification before accessing your account, like a password and a code sent to your phone."},
        {"how to avoid scams","Be cautious when receiving unsolicited messages, especially those asking for money or personal information. Always verify before responding."},
        {"what is malware","Malware is malicious software that can harm your device or steal your data. It includes viruses, spyware, and ransomware."},
        {"how do i stop hackers","Use strong, unique passwords, enable two‑factor authentication (2FA), and keep your software updated to protect against hacking attempts."},
        {"should i click on unknown links","No, avoid clicking on links from unknown sources, as they may lead to phishing sites or infect your device with malware."},
        {"how can i protect my phone","Install updates regularly, use a secure lock screen, avoid downloading apps from untrusted sources, and enable remote wiping in case your phone is lost or stolen."},
        {"what should i do if my data is breached","Immediately change your passwords, monitor your accounts for suspicious activity, and consider placing a fraud alert on your credit report."},
        {"how does encryption work","Encryption turns data into a secure format that can only be read by someone with the correct decryption key, ensuring that unauthorized users cannot access your data."},
        {"why should i update my software","Updating your software ensures you have the latest security patches to protect against vulnerabilities that could be exploited by hackers."},
        {"can someone steal my identity online","Yes, identity theft can occur through phishing, data breaches, or by accessing personal information from unsecure websites. Always be cautious about sharing personal information online."},
        {"is it safe to shop online","Yes, but make sure the website is secure (look for HTTPS) and avoid saving payment details on sites you don’t trust."},
        {"what is a firewall","A firewall monitors and controls incoming and outgoing network traffic based on predetermined security rules. It acts as a barrier between your computer and potential threats from the internet."},
        {"can i trust email attachments","Only open email attachments from trusted sources. If you're unsure, contact the sender directly and verify before opening anything."},
        {"how to spot a phishing email","Phishing emails often contain urgent or alarming language, ask for personal information, and include suspicious links. Always double‑check the sender’s email address."},
        {"what is a vpn","A Virtual Private Network (VPN) encrypts your internet connection, making your online activity private and securing it from hackers, especially on public networks."},
        {"what are security patches","Security patches are updates to software that fix vulnerabilities that hackers could exploit to gain unauthorized access to your device or data."},
        {"online scams","Never transfer money to anyone you've never met in person. Also, don't pay for airplane tickets, medical expenses, customs fees, gambling debts, or visas if asked to do so by someone you've met online. And never send compromising photos to strangers."}
    };

        public MainWindow()
        {
            InitializeComponent();
            Respond("Hello! What is your name?");
        }

        private void SendButton_Click(object s, RoutedEventArgs e)
        {
            string input = UserInputBox.Text.Trim().ToLower();
            if (string.IsNullOrWhiteSpace(input)) return;
            AddChatMessage("You: " + input);
            UserInputBox.Clear();

            if (userName == null)
            {
                userName = input;
                Respond($"Hello {userName}, welcome to the Cybersecurity Awareness Chatbot! Ask me anything, or type 'exit':");
                return;
            }
            if (input == "exit")
            {
                Respond("Goodbye! Stay safe online.");
                File.WriteAllLines("ChatbotMemory.txt", conversationMemory);
                Application.Current.Shutdown();
                return;
            }
            conversationMemory.Add("User: " + input);

            foreach (string sig in topicIndicators)
            {
                if (input.Contains(sig))
                {
                    string after = input[(input.IndexOf(sig) + sig.Length)..].Trim(' ', '.', ',');
                    if (!string.IsNullOrEmpty(after))
                    {
                        favoriteTopic = after;
                        Respond($"Got it! You seem interested in {favoriteTopic}. I’ll remember that.");
                        return;
                    }
                }
            }
            if (input.Contains("favorite topic") && favoriteTopic != null)
            {
                Respond($"Earlier you mentioned you're interested in {favoriteTopic}. Want to learn more?");
                return;
            }

            if (worryWords.Any(w => input.Contains(w)))
                Respond($"I understand your concern, {userName}. I’m here to help you stay safe online.");
            else if (angerWords.Any(w => input.Contains(w)))
                Respond($"It's valid to feel that way, {userName}. Let's solve this together.");
            else if (sadnessWords.Any(w => input.Contains(w)))
                Respond($"I’m sorry you're feeling that way, {userName}. You’re not alone.");

            foreach (var kvp in responses)
                if (input.Contains(kvp.Key))
                {
                    Respond(kvp.Value);
                    return;
                }

            if (input.Contains("add") && input.Contains("task"))
            {
                string title = input.Replace("add task", "").Replace("add a task", "").Trim();
                tasks.Add(new TaskItem { Title = title, Description = title });
                activityLog.Add($"Task added: '{title}'");
                Respond($"Task added: '{title}'. Would you like to set a reminder?");
                return;
            }
            if (input.Contains("remind me to"))
            {
                string title = input.Split("remind me to")[1].Trim(' ', '.', '!');
                var t = new TaskItem { Title = title, Description = title, ReminderDate = DateTime.Now.AddDays(1) };
                tasks.Add(t);
                activityLog.Add($"Reminder set for '{title}' tomorrow");
                Respond($"Reminder set for '{title}' on {t.ReminderDate:MMM dd, yyyy}.");
                return;
            }
            if (input.Contains("view tasks") || input.Contains("show tasks"))
            {
                if (tasks.Count == 0) { Respond("You have no tasks."); }
                else
                {
                    Respond("Here are your tasks:");
                    for (int i = 0; i < tasks.Count; i++)
                    {
                        var t = tasks[i];
                        Respond($"{i + 1}. {t.Title} - {(t.IsCompleted ? "✅" : "⏳")}{(t.ReminderDate != null ? $" (Reminder: {t.ReminderDate:MMM dd})" : "")}");
                    }
                }
                return;
            }
            if (input.Contains("complete task"))
            {
                string match = input.Replace("complete task", "").Trim();
                var t = tasks.FirstOrDefault(x => x.Title.ToLower().Contains(match));
                if (t != null)
                {
                    t.IsCompleted = true;
                    activityLog.Add($"Task completed: '{t.Title}'");
                    Respond($"Task '{t.Title}' marked completed.");
                }
                else Respond("Task not found.");
                return;
            }
            if (input.Contains("delete task"))
            {
                string match = input.Replace("delete task", "").Trim();
                var t = tasks.FirstOrDefault(x => x.Title.ToLower().Contains(match));
                if (t != null)
                {
                    tasks.Remove(t);
                    activityLog.Add($"Task deleted: '{t.Title}'");
                    Respond($"Task '{t.Title}' deleted.");
                }
                else Respond("Task not found.");
                return;
            }
            if (input.Contains("show activity log") || input.Contains("what have you done"))
            {
                var recent = activityLog.TakeLast(5).ToList();
                Respond("Here's a summary of recent actions:");
                for (int i = 0; i < recent.Count; i++)
                    Respond($"{i + 1}. {recent[i]}");
                return;
            }
            if (input.Contains("quiz"))
            {
                quizInProgress = true;
                quizIndex = 0;
                quizScore = 0;
                activityLog.Add("Quiz started");
                Respond("Let's start the Cybersecurity Quiz!");
                ShowNextQuiz();
                return;
            }
            if (quizInProgress)
            {
                if (int.TryParse(input, out int ans) && ans - 1 == quizQuestions[quizIndex - 1].CorrectIndex)
                {
                    quizScore++;
                    Respond($"Correct! {quizQuestions[quizIndex - 1].Explanation}");
                }
                else if (int.TryParse(input, out _))
                {
                    Respond($"Incorrect. {quizQuestions[quizIndex - 1].Explanation}");
                }
                else
                {
                    Respond("Please answer with the question number.");
                    return;
                }
                if (quizIndex < quizQuestions.Count)
                    ShowNextQuiz();
                else
                {
                    Respond($"Quiz complete! You scored {quizScore}/{quizQuestions.Count}.");
                    if (quizScore >= 8) Respond("Great job! You're a cybersecurity pro!");
                    else if (quizScore >= 5) Respond("Good effort! Keep learning!");
                    else Respond("Keep practicing—you'll improve!");
                    activityLog.Add($"Quiz completed: {quizScore}/{quizQuestions.Count}");
                    quizInProgress = false;
                }
                return;
            }

            Respond("I'm not sure about that—please try rephrasing.");
        }

        private void ShowNextQuiz()
        {
            var q = quizQuestions[quizIndex++];
            Respond($"Q{quizIndex}: {q.Question}");
            for (int i = 0; i < q.Choices.Length; i++)
                Respond($"{i + 1}. {q.Choices[i]}");
        }

        private void AddChatMessage(string msg)
        {
            ConversationPanel.Children.Add(new TextBlock { Text = msg, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(5) });
            conversationMemory.Add(msg);
        }

        private void Respond(string msg)
        {
            AddChatMessage("Chatbot: " + msg);
            synth.Speak(msg);
        }

        
        private void StartQuizButton_Click(object sender, RoutedEventArgs e)
        {
            if (quizInProgress)
            {
                Respond("A quiz is already in progress.");
                return;
            }

            quizInProgress = true;
            quizIndex = 0;
            quizScore = 0;
            activityLog.Add("Quiz started via button");
            Respond("Let's start the Cybersecurity Quiz!");
            ShowNextQuiz();
        }
    }

    public class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? ReminderDate { get; set; }
        public bool IsCompleted { get; set; } = false;
    }

    public class QuizQuestion
    {
        public string Question { get; }
        public string[] Choices { get; }
        public int CorrectIndex { get; }
        public string Explanation { get; }

        public QuizQuestion(string q, string[] c, int ci, string e)
        {
            Question = q; Choices = c; CorrectIndex = ci; Explanation = e;
        }
    }
}