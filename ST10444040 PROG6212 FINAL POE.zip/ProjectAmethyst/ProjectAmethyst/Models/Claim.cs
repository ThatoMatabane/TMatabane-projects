﻿using System;

namespace ProjectAmethyst.Models
{
    public class Claim
    {
        public int Id { get; set; }
        public int ContractorId { get; set; }
        public Contractor Contractor { get; set; } = null!;
        public decimal HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal TotalPayment { get; set; }
        public string Status { get; set; } = "Pending";
        public DateTime ClaimDate { get; set; }
    }
}
