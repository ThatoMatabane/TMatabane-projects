﻿using ProjectAmethyst.Models;
using System.Collections.Generic;
using System.Linq;

namespace ProjectAmethyst.Data
{
    public static class FakeDatabase
    {
        public static List<User> Users { get; } = new List<User>
        {
            new User { Id = 1, Username = "admin", Password = "admin123", Role = "HR" },
            new User { Id = 2, Username = "lecturer1", Password = "pass", Role = "Coordinator" },
            new User { Id = 3, Username = "contractor1", Password = "pass", Role = "Contractor" }
        };

        public static List<Contractor> Contractors { get; } = new List<Contractor>
        {
            new Contractor { Id = 1, Name = "Dr. Alice", Email = "alice@example.com" },
            new Contractor { Id = 2, Name = "Mr. Bob", Email = "bob@example.com" }
        };

        public static List<Claim> Claims { get; } = new List<Claim>();
    }
}
