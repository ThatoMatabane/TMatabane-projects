﻿using Microsoft.EntityFrameworkCore;
using ProjectAmethyst.Models;

namespace ProjectAmethyst.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Contractor> Contractors { get; set; }
        public DbSet<Claim> Claims { get; set; }

        

            
        }
    }

