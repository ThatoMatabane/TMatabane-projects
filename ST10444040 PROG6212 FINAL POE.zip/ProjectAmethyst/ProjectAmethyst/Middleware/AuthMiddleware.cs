﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace ProjectAmethyst.Middleware
{
    public class AuthMiddleware
    {
        private readonly RequestDelegate _next;

        public AuthMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var path = context.Request.Path.ToString().ToLower();

            // Allow login + register
            if (path.Contains("/account/login") || path.Contains("/account/register"))
            {
                await _next(context);
                return;
            }

            // Block EVERYTHING else
            if (context.Session.GetString("Username") == null)
            {
                context.Response.Redirect("/Account/Login");
                return;
            }

            await _next(context);
        }
    }
}
