﻿using Microsoft.AspNetCore.Mvc;
using ProjectAmethyst.Data;
using ProjectAmethyst.Models;
using System.Linq;

namespace ProjectAmethyst.Controllers
{
    public class ClaimController : Controller
    {
        // Only Lecturers/Contractors create claims
        public IActionResult Index()
        {
            string username = HttpContext.Session.GetString("Username");
            string role = HttpContext.Session.GetString("Role");

            if (string.IsNullOrEmpty(username))
                return RedirectToAction("Login", "Account");

            var claims = FakeDatabase.Claims.AsEnumerable();

            // Lecturers see only their own claims
            if (role == "Contractor")
                claims = claims.Where(c => c.Contractor?.Name == username);

            return View(claims.OrderByDescending(c => c.ClaimDate));
        }

        public IActionResult Create()
        {
            string role = HttpContext.Session.GetString("Role");
            string username = HttpContext.Session.GetString("Username");

            if (string.IsNullOrEmpty(username))
                return RedirectToAction("Login", "Account");

            if (role == "HR" || role == "Coordinator")
            {
                TempData["Error"] = "Only Lecturers can create claims!";
                return RedirectToAction("Index");
            }

            ViewBag.Contractors = FakeDatabase.Contractors;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(int ContractorId, decimal HoursWorked, decimal HourlyRate)
        {
            string username = HttpContext.Session.GetString("Username");
            string role = HttpContext.Session.GetString("Role");

            if (string.IsNullOrEmpty(username))
                return RedirectToAction("Login", "Account");

            if (role == "HR" || role == "Coordinator")
            {
                TempData["Error"] = "Only Lecturers can create claims!";
                return RedirectToAction("Index");
            }

            var contractor = FakeDatabase.Contractors.FirstOrDefault(c => c.Id == ContractorId);
            if (contractor == null)
            {
                TempData["Error"] = "Invalid contractor selected.";
                return RedirectToAction("Create");
            }

            int newId = FakeDatabase.Claims.Count > 0 ? FakeDatabase.Claims.Max(c => c.Id) + 1 : 1;
            var claim = new Claim
            {
                Id = newId,
                ContractorId = ContractorId,
                Contractor = contractor,
                HoursWorked = HoursWorked,
                HourlyRate = HourlyRate,
                TotalPayment = HoursWorked * HourlyRate,
                Status = "Pending",
                ClaimDate = DateTime.Now
            };

            FakeDatabase.Claims.Add(claim);
            TempData["Success"] = "Claim submitted successfully!";
            return RedirectToAction("Index");
        }
    }
}
