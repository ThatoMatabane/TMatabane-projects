﻿using Microsoft.AspNetCore.Mvc;
using ProjectAmethyst.Data;
using ProjectAmethyst.Models;
using System.Linq;

namespace ProjectAmethyst.Controllers
{
    public class ContractorController : Controller
    {
        // GET: Contractor
        public IActionResult Index()
        {
            var role = HttpContext.Session.GetString("Role");

            if (string.IsNullOrEmpty(role) || (role != "HR" && role != "Coordinator"))
            {
                TempData["Error"] = "Access denied. Only HR and Coordinator can view contractors.";
                return RedirectToAction("Login", "Account");
            }

            return View(FakeDatabase.Contractors);
        }

        // GET: Contractor/Create
        public IActionResult Create()
        {
            var role = HttpContext.Session.GetString("Role");

            if (string.IsNullOrEmpty(role) || role != "Coordinator")
            {
                TempData["Error"] = "Access denied. Only Coordinator can add contractors.";
                return RedirectToAction("Index");
            }

            return View();
        }

        // POST: Contractor/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Contractor contractor)
        {
            var role = HttpContext.Session.GetString("Role");

            if (string.IsNullOrEmpty(role) || role != "Coordinator")
            {
                TempData["Error"] = "Access denied. Only Coordinator can add contractors.";
                return RedirectToAction("Index");
            }

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Invalid data submitted.";
                return View(contractor);
            }

            // Assign ID manually since it's in-memory
            contractor.Id = FakeDatabase.Contractors.Count > 0
                ? FakeDatabase.Contractors.Max(c => c.Id) + 1
                : 1;

            FakeDatabase.Contractors.Add(contractor);
            TempData["Success"] = "Contractor added successfully!";
            return RedirectToAction("Index");
        }
    }
}
