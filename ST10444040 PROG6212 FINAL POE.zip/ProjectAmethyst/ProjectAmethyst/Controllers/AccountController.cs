﻿using Microsoft.AspNetCore.Mvc;
using ProjectAmethyst.Data;
using ProjectAmethyst.Models;
using System.Linq;

namespace ProjectAmethyst.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Register() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(string username, string password, string role)
        {
            if (string.IsNullOrWhiteSpace(role))
            {
                TempData["Error"] = "Please select a role.";
                return View();
            }

            if (FakeDatabase.Users.Any(u => u.Username == username))
            {
                TempData["Error"] = "Username already exists!";
                return View();
            }

            int newId = FakeDatabase.Users.Count > 0 ? FakeDatabase.Users.Max(u => u.Id) + 1 : 1;
            var user = new User
            {
                Id = newId,
                Username = username,
                Password = password,
                Role = role
            };

            FakeDatabase.Users.Add(user);
            TempData["Success"] = "Account created successfully!";
            return RedirectToAction("Login");
        }

        public IActionResult Login() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(string username, string password)
        {
            var user = FakeDatabase.Users.FirstOrDefault(u => u.Username == username && u.Password == password);
            if (user == null)
            {
                TempData["Error"] = "Invalid username or password!";
                return View();
            }

            HttpContext.Session.SetString("Username", user.Username);
            HttpContext.Session.SetString("Role", user.Role);

            // Redirect based on role
            if (user.Role == "HR" || user.Role == "Coordinator")
                return RedirectToAction("HRIndex", "HR");

            return RedirectToAction("Index", "Claim"); // Lecturers/Contractors
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
