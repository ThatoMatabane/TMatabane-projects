﻿using Microsoft.AspNetCore.Mvc;
using ProjectAmethyst.Data;
using System.Linq;

namespace ProjectAmethyst.Controllers
{
    public class HRController : Controller
    {
        public IActionResult HRIndex()
        {
            string role = HttpContext.Session.GetString("Role");
            if (role != "HR" && role != "Coordinator")
            {
                TempData["Error"] = "You do not have access to this page.";
                return RedirectToAction("Index", "Claim");
            }

            ViewBag.ContractorCount = FakeDatabase.Contractors.Count;
            ViewBag.ClaimCount = FakeDatabase.Claims.Count;
            ViewBag.TotalPayout = FakeDatabase.Claims.Sum(c => c.TotalPayment);

            return View(FakeDatabase.Claims.OrderByDescending(c => c.ClaimDate));
        }

        // Approve, Reject, or Pend claims
        public IActionResult UpdateStatus(int id, string status)
        {
            string role = HttpContext.Session.GetString("Role");
            if (role != "HR" && role != "Coordinator")
            {
                TempData["Error"] = "You do not have access!";
                return RedirectToAction("Index", "Claim");
            }

            var claim = FakeDatabase.Claims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.Status = status;
                TempData["Success"] = $"Claim marked as {status}.";
            }
            return RedirectToAction("HRIndex");
        }
    }
}
